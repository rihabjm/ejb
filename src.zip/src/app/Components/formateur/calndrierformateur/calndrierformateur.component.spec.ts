import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CalndrierformateurComponent } from './calndrierformateur.component';

describe('CalndrierformateurComponent', () => {
  let component: CalndrierformateurComponent;
  let fixture: ComponentFixture<CalndrierformateurComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CalndrierformateurComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CalndrierformateurComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
