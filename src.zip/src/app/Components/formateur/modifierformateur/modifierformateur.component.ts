import { Component, OnInit,Input } from '@angular/core';
import {Formateur} from '../../../Model/Formateur';
import {FormateurService} from '../../../Service/formateur.service';
import {FileService} from '../../../Service/file.service';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ListformateurComponent } from '../listformateur/listformateur.component';
import {UploadfileService} from '../../../Service/uploadfile.service';
import { Observable } from 'rxjs';
import {Specilaite} from '../../../Model/Specilaite';
import {SpecialiteService} from '../../../Service/specialite.service';

@Component({
  selector: 'app-modifierformateur',
  templateUrl: './modifierformateur.component.html',
  styleUrls: ['./modifierformateur.component.scss']
})
export class ModifierformateurComponent implements OnInit {


message  :String ;
  constructor(private specialiteService :SpecialiteService   ,private uploadService : UploadfileService, private _Activatedroute:ActivatedRoute, private router: Router ,private formateurService: FormateurService ) { }
   sub;
    id ;


     formateur : Formateur ;

formateurs: Formateur[] = new Array();
 specialites: Specilaite[] = new Array();
 specialiteschoisi: Specilaite[] = new Array();
 specialiteformateur :Specilaite[] = new Array();

  ngOnInit() {this.getAll() ;


      this.sub=this._Activatedroute.paramMap.subscribe(params => {
         console.log(params);
                   this.id = params.get('id');
              this.formateurService.get(this.id)
      .subscribe(data => {
        console.log(data)
        this.formateur = data;
        this.specialiteformateur=data.specialites ;
      }, error => console.log(error));

      });




    this.getspecialite();
    this.showFilesCv();

  }



    selectedFile: File;


 public onFileChanged(event) {
    //Select File
    this.selectedFile = event.target.files[0];
  }



  specialiteselectionner :Specilaite  ;





 selectedFiles: FileList;
  currentFileUpload: File;
  progress: { percentage: number } = { percentage: 0 };
sp :number ;

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }


 private upload() {
    this.progress.percentage = 0;

    this.currentFileUpload = this.selectedFiles.item(0);
    this.uploadService.pushFileToStoragecv(this.currentFileUpload,this.id ).subscribe(event => {

    });

    this.selectedFiles = undefined;
  }

  private uploadcertif() {
    this.progress.percentage = 0;

    this.currentFileUpload = this.selectedFiles.item(0);
    this.uploadService.pushFileToStoragecertificat(this.currentFileUpload,this.id,this.sp).subscribe(event => {

    });
 this.formateurService.affectspecialite(this.sp,this.id).subscribe( data => {
            });
    this.selectedFiles = undefined;
  }


  getspecialite()
  {
    this.specialiteService.list().subscribe((data: any) => {
    this.specialites=data ;

       });
  }



showFile = false;
  fileUploads1: Observable<string[]>;
 fileUploads: Observable<string[]>;

private   showFilesCv() {

      this.fileUploads1 = this.uploadService.getFilesCv(this.id);

  }
private   showFilesCertificat(spc :number) {

      this.fileUploads = this.uploadService.getFilesCertifcat(this.id,spc);

  }


 @Input() fileUpload: string;



private getAll() {
 this.formateurService.getAll().subscribe(data => {
 this.formateurs=data ;
      console.log(this.formateurs);
    }, ex => {
      console.log(ex);
    });}




  private update(formateur:Formateur) {
    this.formateurService.update(formateur).subscribe(
data => {

     if (data.success) { this.getAll();

     this.message ="formateur modifié ";

     } else {
          this.message ="echec de modification ";

     }
    }, ex => {console.log(ex);
    });
  }


}
