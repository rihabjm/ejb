import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calendrierformateur',
  templateUrl: './calendrierformateur.component.html',
  styleUrls: ['./calendrierformateur.component.scss']
})
export class CalendrierformateurComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
