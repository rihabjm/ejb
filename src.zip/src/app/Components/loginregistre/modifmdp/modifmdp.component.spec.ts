import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifmdpComponent } from './modifmdp.component';

describe('ModifmdpComponent', () => {
  let component: ModifmdpComponent;
  let fixture: ComponentFixture<ModifmdpComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModifmdpComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifmdpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
