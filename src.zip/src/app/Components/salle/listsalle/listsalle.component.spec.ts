import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListsalleComponent } from './listsalle.component';

describe('ListsalleComponent', () => {
  let component: ListsalleComponent;
  let fixture: ComponentFixture<ListsalleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListsalleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListsalleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
