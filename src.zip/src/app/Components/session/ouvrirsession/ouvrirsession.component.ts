import { Component, OnInit } from '@angular/core';
import {FormControl,FormGroup,Validators} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import {Formationmodule} from '../../../Model/formationmodule';
import {FormationmoduleService} from '../../../Service/formationmodule.service';

@Component({
  selector: 'app-ouvrirsession',
  templateUrl: './ouvrirsession.component.html',
  styleUrls: ['./ouvrirsession.component.scss']
})
export class OuvrirsessionComponent implements OnInit {




private getAll() {
 this.formationmoduleserice.getAll().subscribe(data => {
 this.formationsmodules=data ;
      console.log(this.formationsmodules);
    }, ex => {
      console.log(ex);
    });}



  private update(formationmodule:Formationmodule) {
    this.formationmoduleserice.update(formationmodule).subscribe(
data => {

     if (data.success) { this.getAll();} else {}
    }, ex => {console.log(ex);
    });
  }








  constructor(private _Activatedroute:ActivatedRoute, private router: Router , private formationmoduleserice: FormationmoduleService ) { }
   sub;
    id ;


     formationmodule : Formationmodule =new Formationmodule() ;

formationsmodules: Formationmodule[] = new Array();

  ngOnInit() {this.getAll() ;


      this.sub=this._Activatedroute.paramMap.subscribe(params => {
         console.log(params);
                   this.id = params.get('id');
              this.formationmoduleserice.get(this.id)
      .subscribe(data => {
        console.log(data)
        this.formationmodule = data;
      }, error => console.log(error));

      });


  }









}
