import {Observable} from 'rxjs';
import {Session} from './Session';
import {Formateur} from './formateur';
export class Formation {
idformation:number ;
intitule : String ;
prix :String ;
datedebut : String;
datefin:String ;
etat : String;
type: String ;
description: String ;
formateur :Formateur ;

}
