import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Formateur} from '../Model/formateur';
import {Specilaite} from '../Model/specilaite';
@Injectable({
  providedIn: 'root'
})
export class FormateurService {
  constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/formateur';
private urldetail =this.url+'/byid';
private urlaffect =this.url+'/affectspecialite' ;
 public save(formateur:Formateur): Observable<any>  {

  return this.httpClient.post(this.url+'/add',formateur );
  }

 affectspecialite(idsp :number,   idCategory: number): Observable<any> {
    return this.httpClient.put(`${this.urlaffect }/${idCategory}`,idsp);
  }



  public  getAll(): Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url+'/get');
  }
 public update(formateur:Formateur): Observable<any> {

  return this.httpClient.put(this.url+'/update' ,formateur);
  }

   public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);

  }
   public get(id: number): Observable<any> {
    return this.httpClient.get(`${this.urldetail }/${id}`);
  }

 public getUserById(id): Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url + '/byid/' + id);
  }



 public getUserByNom(nom): Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url + '/bynom/' + nom);
  }
public getUserByPrenom(prenom): Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url + '/byprenom/' + prenom);
  }

public getUserByAdresse(adresse): Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url + '/byadresse/' + adresse);
  }
public getUserByTelephone(telephone): Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url + '/bytel/' + telephone);
  }
public getUserByGmail(gmail) : Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url + '/bygmail) /' + gmail );
  }
public getUserByDateNAisse(dateNAisse) : Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url + '/bydatenaiss) /' + dateNAisse );
  }




  public getUserBySexe(sexe) : Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url + '/bysexe) /' + sexe);
  }
  public getUserByFacebook(facebook ): Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url + '/byfacebook) /' + facebook );
  }
  public getUserByLinked(linked): Observable<Formateur[]> {
    return this.httpClient.get<Formateur[]>(this.url + '/bylinked) /' + linked );
  }




   public getspecialiteformateur(id: number): Observable<any> {
    return this.httpClient.get<Specilaite[]>(this.url +'/getspecialite/' + id );
  }




}
