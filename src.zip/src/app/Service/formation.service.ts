import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {Formation} from '../Model/formation';
@Injectable({
  providedIn: 'root'
})
export class FormationService {
  constructor(private httpClient: HttpClient) { }

private url = Config.BASE_URL + '/formation';
private urldetail =Config.BASE_URL + '/formation/byid'



  public  getAll(): Observable<Formation[]> {
    return this.httpClient.get<Formation[]>(this.url+'/get');
  }

   public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }

   public getformationNotAffected(datedeb:String,datefin:String): Observable<Formation[]> {
    return this.httpClient.get<Formation[]>(this.url  + '/getnotaffect '+{datedeb,datefin} );
  }
  public affecte(Formations: Formation[]): Observable<any> {
    return this.httpClient.post(this.url+'/affecte', Formations);
  }

  public get(id: number): Observable<any> {
    return this.httpClient.get(`${this.urldetail }/${id}`);
  }
 public getformation(id): Observable<Formation[]> {
    return this.httpClient.get<Formation[]>(this.url + '/byid/' + id);
  }

 public getformationBYintitule(intitule): Observable<Formation[]> {
    return this.httpClient.get<Formation[]>(this.url + '/byintitule/' + intitule);
  }
 public getformationBydatedebut(datedeb): Observable<Formation[]> {
    return this.httpClient.get<Formation[]>(this.url + '/bydatedeb/' + datedeb);
  }
public getformationBydatefin(datefin): Observable<Formation[]> {
    return this.httpClient.get<Formation[]>(this.url + '/bydatefin/' + datefin);
  }
public getformationByetat(etat): Observable<Formation[]> {
    return this.httpClient.get<Formation[]>(this.url + '/byetat/' + etat);
  }
public getformationBytype(type): Observable<Formation[]> {
    return this.httpClient.get<Formation[]>(this.url + '/bytype/' + type);
  }
public getformationByprix(prix): Observable<Formation[]> {
    return this.httpClient.get<Formation[]>(this.url + '/byprix/' + prix);
  }




}
