import { Injectable } from '@angular/core';
import {HttpClient, HttpParams} from '@angular/common/http';
import {Config} from '../Utils/Config';
import {Observable} from 'rxjs';
import {ProgrammeKhademni} from '../Model/programme-khademni';
@Injectable({
  providedIn: 'root'
})
export class ProgrammekhdemniService {

 constructor(private httpClient: HttpClient) { }
private url = Config.BASE_URL + '/programmekhademni';
private urldetails = this.url + '/byid';


 public save(formation:ProgrammeKhademni): Observable<any> {

  return this.httpClient.post(this.url+'/add',formation );
  }

  public  getAll(): Observable<ProgrammeKhademni[]> {
    return this.httpClient.get<ProgrammeKhademni[]>(this.url+'/get');
  }
 public update(formation:ProgrammeKhademni): Observable<any> {

  return this.httpClient.put(this.url+'/update' ,formation);
  }
 public getformation(id): Observable<ProgrammeKhademni[]> {
    return this.httpClient.get<ProgrammeKhademni[]>(this.url + '/byid/' + id);
  }

   public delete(id): Observable<any> {
    return this.httpClient.delete(this.url + '/' + id);
  }
   public get(id: number): Observable<any> {
    return this.httpClient.get(`${this.urldetails }/${id}`);
  }

 public getformationBYintitule(intitule): Observable<ProgrammeKhademni[]> {
    return this.httpClient.get<ProgrammeKhademni[]>(this.url + '/byintitule/' + intitule);
  }
 public getformationBydatedebut(datedeb): Observable<ProgrammeKhademni[]> {
    return this.httpClient.get<ProgrammeKhademni[]>(this.url + '/bydatedeb/' + datedeb);
  }
public getformationBydatefin(datefin): Observable<ProgrammeKhademni[]> {
    return this.httpClient.get<ProgrammeKhademni[]>(this.url + '/bydatefin/' + datefin);
  }
public getformationByetat(etat): Observable<ProgrammeKhademni[]> {
    return this.httpClient.get<ProgrammeKhademni[]>(this.url + '/byetat/' + etat);
  }
public getformationBytype(type): Observable<ProgrammeKhademni[]> {
    return this.httpClient.get<ProgrammeKhademni[]>(this.url + '/bytype/' + type);
  }
public getformationByprix(prix): Observable<ProgrammeKhademni[]> {
    return this.httpClient.get<ProgrammeKhademni[]>(this.url + '/byprix/' + prix);
  }



}
