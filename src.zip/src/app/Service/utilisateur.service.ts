import { Injectable } from '@angular/core';
import {HttpBackend, HttpClient} from '@angular/common/http';
import {Config} from '../utils/Config';
import {Utilisateur} from '../model/utilisateur';
import {Observable} from 'rxjs';
import {JwtHelperService} from '@auth0/angular-jwt';
@Injectable({
  providedIn: 'root'
})
export class UtilisateurService {
  private url = Config.BASE_URL + '/utilisateur';

  // tslint:disable-next-line:max-line-length
  // private header = new HttpHeaders({'authorization': 'bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1c2VyMUBnbWFpbCIsInJvbGVzIjpbIlVTRVIiXSwiaXNzIjoiL2xvZ2luIiwiZXhwIjoxNTc1NDg4Nzc5fQ.k8ZKAtZUaGXefvsTgqyku_pANq_sH5rbd2NV0xQxLFM'});
  constructor(private httpClient: HttpClient) { }

  add(user: Utilisateur): Observable<object> {
    return this.httpClient.post(this.url + '/register', user);
  }

  list(): Observable<any> {
    return this.httpClient.get(this.url + '/list', );
  }

  remove(id) {
    return this.httpClient.delete(this.url + 'Users/' + id, );
  }

  modify(idUser: number, user: Utilisateur): Observable<any> {
    return this.httpClient.put( this.url + '/update/' + idUser, user);
  }

  findById(id): Observable<any> {
    return this.httpClient.get(this.url + '/user/' + id);
  }
  findByEmail(email): Observable<any> {
    return this.httpClient.get(this.url + '/usermail/' + email); }

 public getUser(): Observable<any> {
    const jwtHelper = new JwtHelperService();
    const decoded =   jwtHelper.decodeToken(localStorage.getItem('token'));
    const email = decoded.sub;
    return this.httpClient.get<any>(this.url+'/usermail/' + email);



  }



 public getUserById(id): Observable<Utilisateur[]> {
    return this.httpClient.get<Utilisateur[]>(this.url + '/byid/' + id);
  }



 public getUserByNom(nom): Observable<Utilisateur[]> {
    return this.httpClient.get<Utilisateur[]>(this.url + '/bynom/' + nom);
  }
public getUserByPrenom(prenom): Observable<Utilisateur[]> {
    return this.httpClient.get<Utilisateur[]>(this.url + '/byprenom/' + prenom);
  }

public getUserByAdresse(adresse): Observable<Utilisateur[]> {
    return this.httpClient.get<Utilisateur[]>(this.url + '/byadresse/' + adresse);
  }
public getUserByTelephone(telephone): Observable<Utilisateur[]> {
    return this.httpClient.get<Utilisateur[]>(this.url + '/bytel/' + telephone);
  }
public getUserByGmail(gmail) : Observable<Utilisateur[]> {
    return this.httpClient.get<Utilisateur[]>(this.url + '/bygmail) /' + gmail );
  }
public getUserByDateNAisse(dateNAisse) : Observable<Utilisateur[]> {
    return this.httpClient.get<Utilisateur[]>(this.url + '/bydatenaiss) /' + dateNAisse );
  }




  public getUserBySexe(sexe) : Observable<Utilisateur[]> {
    return this.httpClient.get<Utilisateur[]>(this.url + '/bysexe) /' + sexe);
  }
  public getUserByFacebook(facebook ): Observable<Utilisateur[]> {
    return this.httpClient.get<Utilisateur[]>(this.url + '/byfacebook) /' + facebook );
  }
  public getUserByLinked(linked): Observable<Utilisateur[]> {
    return this.httpClient.get<Utilisateur[]>(this.url + '/bylinked) /' + linked );
  }




}
